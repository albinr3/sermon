"""Service layer for external integrations."""
