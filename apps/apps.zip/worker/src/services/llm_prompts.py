"""Shared LLM prompts.

Single source of truth so Deepseek/OpenAI use identical system/user prompts.
"""

from __future__ import annotations

import json


def scoring_system_prompt() -> str:
    return (
        "Eres un experto en evaluar clips de sermones para redes sociales. "
        "Criterios de evaluacion (0-100): "
        "1. HOOK (0-25): captura atencion en los primeros segundos. "
        "2. CLARIDAD (0-25): se entiende sin contexto previo. "
        "3. APLICABILIDAD (0-25): relevante para la vida diaria. "
        "4. EMOCION (0-25): genera respuesta emocional. "
        "Prioriza clips que sean autonomos, con conclusion clara, "
        "compartibles en redes sociales y conecten emocionalmente. "
        "Devuelve SOLO JSON (sin markdown) como una lista de objetos con: "
        "id, score (0-100), reason, y opcional trim_suggestion "
        "(start_offset_sec, end_offset_sec, confidence). "
        "Los offsets son segundos a recortar desde inicio y fin (>=0), "
        "confidence es de 0 a 1. "
        "Si sugieres recortes, mantenlos pequenos y evita cortar palabras."
    )


def scoring_user_prompt(prompt_candidates: list[dict]) -> str:
    return (
        "Candidates JSON:\n"
        f"{json.dumps(prompt_candidates, ensure_ascii=True)}\n\n"
        "Return a JSON array with one entry per candidate id."
    )


def selection_system_prompt(*, target_count: int) -> str:
    return (
        "Eres un experto en identificar MEJORES momentos de sermones para redes sociales. "
        "Selecciona los 10 MEJORES de estos candidatos basandote en: "
        "1. IMPACTO EMOCIONAL, 2. MENSAJE COMPLETO, 3. AUTONOMIA, "
        "4. VIRALIDAD, 5. VARIEDAD. "
        "Devuelve SOLO JSON (sin markdown) como una lista de objetos con: "
        "id, score (0-100), reason. "
        "Devuelve exactamente {target_count} resultados si es posible."
    ).format(target_count=target_count)


def selection_user_prompt(*, sermon_context: str, prompt_candidates: list[dict]) -> str:
    sermon_context = sermon_context or ""
    return (
        "Contexto del sermon (primeros 2000 chars):\n"
        f"{sermon_context}\n\n"
        "Candidates JSON:\n"
        f"{json.dumps(prompt_candidates, ensure_ascii=True)}\n\n"
        "Return a JSON array with one entry per selected candidate id."
    )


def full_context_system_prompt() -> str:
    return (
        "Eres un experto en crear clips virales de sermones para redes sociales.\n\n"
        "TAREA: Lee este sermon COMPLETO y genera 10-20 clips optimos.\n\n"
        "CRITERIOS DE SELECCION:\n"
        "1. HOOK FUERTE (0-35 pts):\n"
        "   EXCELENTES (35 pts):\n"
        "   - Pregunta provocadora\n"
        "   - Declaración contraintuitiva\n"
        "   - Verdad universal\n"
        "   - Analogía poderosa\n"
        "   \n"
        "   ACEPTABLES (20 pts):\n"
        "   - Declaración directa con promesa: 'La alegría que ofrece Jesús es diferente'\n"
        "   - Definición + implicación: 'Creer significa seguir, no es pasar al altar'\n"
        "   \n"
        "   MALOS (0 pts):\n"
        "   - 'Y entonces...'\n"
        "   - 'Como dije antes...'\n"
        "   - 'También es importante...'\n"
        "   - 'Ahora bien...'\n"
        "   - Cualquier cosa que requiera contexto previo\n\n"
        "2. UNA SOLA IDEA (0-25 pts):\n"
        "   - El clip debe desarrollar UNA idea completa\n"
        "   - NO intentar cubrir múltiples puntos\n"
        "   - Mensaje debe ser cristalino al terminar\n"
        "   - Test: ¿Puedo resumir este clip en 1 oración?\n\n"
        "3. CONCLUSION FUERTE (0-20 pts):\n"
        "   - Termina con frase memorable\n"
        "   - O con pregunta que invita reflexión\n"
        "   - O con llamado a la acción\n"
        "   - NO terminar en medio de pensamiento\n\n"
        "4. AUTONOMIA (0-15 pts):\n"
        "   - Se entiende SIN contexto previo\n"
        "   - No requiere haber visto el sermón\n"
        "   - No hace referencia a 'lo que dije antes'\n\n"
        "5. EMOCION (0-5 pts):\n"
        "   - Inspira, desafía o conmueve\n"
        "   - Conecta emocionalmente\n\n"
        "REQUISITOS TECNICOS:\n"
        "- Duracion ideal: 40-70 segundos (minimo 30s, maximo 120s)\n"
        "- Inicio y fin en puntos naturales (no cortar palabras/frases)\n"
        "- Variedad: Cubre diferentes temas del sermon\n"
        "- Prioriza momentos con narrativa completa (inicio-desarrollo-conclusion)\n\n"
        "EVITA:\n"
        "- Clips que requieren contexto previo\n"
        "- Momentos que terminan abruptamente\n"
        "- Contenido exclusivamente doctrinal sin aplicacion\n"
        "- Clips muy cortos (<30s) o muy largos (>120s)\n\n"
        "FORMATO DE RESPUESTA (solo JSON, sin markdown):\n"
        "[\n"
        '  {"start_sec": numero, "end_sec": numero, "score": 0-100, "reason": "explicacion", "theme": "tema"}\n'
        "]\n\n"
        "Genera 10-20 clips que cumplan estos criterios."
    )


def full_context_system_prompt_v2() -> str:
    return (
        "Eres un experto en crear clips CORTOS virales de sermones para TikTok, Instagram Reels y YouTube Shorts.\n\n"
        
        "⚠️ REGLA CRÍTICA DE DURACIÓN:\n"
        "- DURACIÓN IDEAL: 30-50 segundos (NO MÁS)\n"
        "- MÍNIMO: 30 segundos\n"
        "- MÁXIMO ABSOLUTO: 60 segundos\n"
        "- Si un momento bueno es >60 segundos, divídelo en 2 clips\n\n"
        
        "¿POR QUÉ 30-50 SEGUNDOS?\n"
        "- TikTok/Reels: Máxima retención en <45 segundos\n"
        "- YouTube Shorts: Límite 60 segundos\n"
        "- Atención del usuario: Se pierde después de 45 segundos\n"
        "- Viralidad: Clips cortos se comparten 3x más\n\n"
        
        "ESTRUCTURA PERFECTA DE UN CLIP DE 40 SEGUNDOS:\n"
        "- 0-5s: HOOK que captura atención\n"
        "- 5-30s: Desarrollo de 1 idea (solo UNA)\n"
        "- 30-40s: Conclusión/punchline\n\n"
        
        "CRITERIOS DE EVALUACIÓN:\n"
        "1. HOOK INICIAL (0-35 pts) - MÁXIMA PRIORIDAD:\n"
        "   \n"
        "   ✅ EXCELENTES (35 pts):\n"
        "   - Pregunta provocadora: '¿Cuándo fue la última vez que seguir a Jesús nos costó una relación?'\n"
        "   - Declaración contraintuitiva: 'Las armas que Dios nos proveyó, aunque parecen arcaicas, siguen funcionando'\n"
        "   - Verdad universal: 'Todos nacemos con un anhelo intenso de significación'\n"
        "   - Analogía poderosa: '¿Podría alguien construir un palacio y olvidarse del rey?'\n"
        "   \n"
        "   ⚠️ ACEPTABLES (20 pts):\n"
        "   - Declaración directa con promesa: 'La alegría que ofrece Jesús es diferente'\n"
        "   - Definición + implicación: 'Creer significa seguir, no es pasar al altar'\n"
        "   \n"
        "   ❌ MALOS (0 pts):\n"
        "   - 'Y entonces...'\n"
        "   - 'Como dije antes...'\n"
        "   - 'También es importante...'\n"
        "   - 'Ahora bien...'\n"
        "   - Cualquier cosa que requiera contexto previo\n\n"
        
        "2. UNA SOLA IDEA (0-25 pts):\n"
        "   - El clip debe desarrollar UNA idea completa\n"
        "   - NO intentar cubrir múltiples puntos\n"
        "   - Mensaje debe ser cristalino al terminar\n"
        "   - Test: ¿Puedo resumir este clip en 1 oración?\n\n"
        
        "3. CONCLUSIÓN FUERTE (0-20 pts):\n"
        "   - Termina con frase memorable\n"
        "   - O con pregunta que invita reflexión\n"
        "   - O con llamado a la acción\n"
        "   - NO terminar en medio de pensamiento\n\n"
        
        "4. AUTONOMÍA (0-15 pts):\n"
        "   - Se entiende SIN contexto previo\n"
        "   - No requiere haber visto el sermón\n"
        "   - No hace referencia a 'lo que dije antes'\n\n"
        
        "5. EMOCIÓN (0-5 pts):\n"
        "   - Inspira, desafía o conmueve\n"
        "   - Conecta emocionalmente\n\n"
        
        "EJEMPLOS DE CLIPS PERFECTOS (30-50 SEGUNDOS):\n"
        "\n"
        "✅ EJEMPLO 1 (42 segundos):\n"
        "Inicio: '¿Cuándo fue la última vez que seguir a Jesús nos costó una relación?'\n"
        "Desarrollo: 'Muchos queremos seguir a Cristo, pero solo cuando es conveniente. Solo cuando no incomoda. Solo cuando no nos cuesta amistades.'\n"
        "Conclusión: 'Pero Jesús nunca prometió comodidad. Prometió que valdría la pena.'\n"
        "Duración: 42 segundos\n"
        "Score: 95/100\n"
        "\n"
        "✅ EJEMPLO 2 (38 segundos):\n"
        "Inicio: 'Todos nacemos con un anhelo intenso de significación.'\n"
        "Desarrollo: 'Buscamos llenar ese vacío con logros, relaciones, dinero. Pero nada lo llena completamente.'\n"
        "Conclusión: 'Porque ese vacío tiene la forma de Dios.'\n"
        "Duración: 38 segundos\n"
        "Score: 90/100\n"
        "\n"
        "❌ EJEMPLO MALO (85 segundos - DEMASIADO LARGO):\n"
        "Inicio: 'La alegría que ofrece Jesús...'\n"
        "Desarrollo: [3 puntos diferentes, 2 ilustraciones]\n"
        "Conclusión: [Se pierde en múltiples ideas]\n"
        "Problema: Intenta cubrir demasiado, pierde enfoque\n"
        "Solución: Dividir en 2 clips de 40 segundos cada uno\n\n"
        
        "REGLAS ESTRICTAS DE TIMING:\n"
        "1. Busca el TIMESTAMP EXACTO donde empieza la frase\n"
        "2. NO cortar en medio de palabra o frase\n"
        "3. Inicio debe ser primera palabra de oración completa\n"
        "4. Final debe ser última palabra de oración completa\n"
        "5. Si encuentras un momento bueno pero >60s, busca un punto natural de corte para dividirlo en 2 clips\n\n"
        
        "FORMATO DE RESPUESTA (SOLO JSON):\n"
        "[\n"
        '  {\n'
        '    "start_sec": número (timestamp exacto),\n'
        '    "end_sec": número (timestamp exacto),\n'
        '    "duration_sec": número (end_sec - start_sec, DEBE SER 30-50),\n'
        '    "score": 0-100,\n'
        '    "reason": "Por qué este clip es excelente",\n'
        '    "theme": "Tema en 3-5 palabras",\n'
        '    "hook": "Primeras 8-12 palabras EXACTAS del clip",\n'
        '    "conclusion": "Últimas 8-12 palabras EXACTAS del clip"\n'
        '  }\n'
        "]\n\n"
        
        "TAREA FINAL:\n"
        "Genera 15-20 clips de 30-50 segundos cada uno, priorizando:\n"
        "1. Hooks más fuertes (preguntas, declaraciones impactantes)\n"
        "2. Duración 30-50 segundos (CRÍTICO)\n"
        "3. Una sola idea por clip\n"
        "4. Variedad de temas\n"
        "5. Ordenados por score (mayor a menor)"
    )


def full_context_user_prompt(*, title: str, preacher: str, duration_label: str, transcript: str) -> str:
    return (
        f"SERMON COMPLETO:\n"
        f"Titulo: {title}\n"
        f"Predicador: {preacher}\n"
        f"Duracion: {duration_label}\n\n"
        f"TRANSCRIPCION CON TIMESTAMPS:\n"
        f"{transcript}\n\n"
        "Analiza todo el sermon y devuelve 10-20 clips en formato JSON."
    )


def windows_system_prompt(*, count: int) -> str:
    return (
        "Eres experto en clips virales. Analiza {count} ventanas y selecciona las "
        "10-12 MEJORES basandote en: HOOK, MENSAJE AUTONOMO, IMPACTO EMOCIONAL, "
        "APLICABILIDAD, VIRALIDAD. Devuelve SOLO JSON (sin markdown) como una lista "
        "de objetos con: window_id, score (0-100), reason, theme, timing_adjustment "
        "(start_offset_sec, end_offset_sec, confidence). Usa confidence 0-1."
    ).format(count=count)


def windows_user_prompt(*, sermon_title: str, sermon_intro: str, prompt_windows: list[dict]) -> str:
    return (
        "Sermon context:\n"
        f"Title: {sermon_title}\n"
        f"Intro: {sermon_intro}\n\n"
        "Windows JSON:\n"
        f"{json.dumps(prompt_windows, ensure_ascii=True)}\n\n"
        "Selecciona las mejores."
    )
